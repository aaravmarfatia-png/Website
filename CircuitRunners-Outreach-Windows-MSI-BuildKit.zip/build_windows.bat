@echo off
REM ============================================================
REM  CircuitRunners Outreach - Windows MSI builder
REM  Run this on a Windows PC with Python 3.10+ installed
REM  (check "Add Python to PATH" during Python setup).
REM  Double-click this file, or run it from Command Prompt.
REM ============================================================
setlocal

echo.
echo === CircuitRunners Outreach: building Windows .msi ===
echo.

where py >nul 2>nul
if %ERRORLEVEL%==0 (
    set "PY=py -3"
) else (
    where python >nul 2>nul
    if %ERRORLEVEL%==0 (
        set "PY=python"
    ) else (
        echo ERROR: Python was not found. Install Python 3.10+ from python.org
        echo         and check "Add Python to PATH" during setup.
        pause
        exit /b 1
    )
)

echo Creating virtual environment...
%PY% -m venv .venv
if %ERRORLEVEL% neq 0 ( echo ERROR: could not create venv & pause & exit /b 1 )

echo Installing dependencies (a couple of minutes the first time)...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\pip.exe" install -r requirements.txt cx_Freeze
if %ERRORLEVEL% neq 0 ( echo ERROR: dependency install failed & pause & exit /b 1 )

echo Building the .msi installer...
".venv\Scripts\python.exe" setup.py bdist_msi
if %ERRORLEVEL% neq 0 ( echo ERROR: MSI build failed & pause & exit /b 1 )

echo.
echo === DONE ===
echo Your installer is in the "dist" folder, for example:
echo     dist\CircuitRunners Outreach-1.0.0-win64.msi
echo Share that .msi with your team. Double-clicking it installs the app
echo and adds a Start Menu shortcut.
echo.
pause
